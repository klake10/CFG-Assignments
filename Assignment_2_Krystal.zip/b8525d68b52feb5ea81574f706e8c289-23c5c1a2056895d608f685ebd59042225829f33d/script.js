const prices = {
    bus: { economy: 30, business: 50, first: 70 },
    train: { economy: 70, business: 100, first: 150 },
    plane: 200
};

function calculatePrice() {
    const journeyType = document.getElementById('journeyType').value;
    const classType = document.getElementById('classType').value;

    let price = prices[journeyType][classType];
    console.log(`Selected ${journeyType} journey with ${classType} class. Initial price: £${price}`);

    if (confirm("Would you like to accept a special offer to take a plane instead for £200?")) {
        price = prices.plane;
    }

    document.getElementById('result').innerHTML = `Total Price: £${price}`;

    promptRating();
}

function promptRating() {
    const rating = prompt("Please rate our service (good/bad):");
    if (rating.toLowerCase() === "good") {
        alert("Amazing!");
    } else if (rating.toLowerCase() === "bad") {
        alert("We will try harder.");
    } else {
        alert("Invalid input.");
    }
}
